#!/usr/bin/env node
/**
 * build-userscript.mjs — assemble the Tampermonkey edition of Volume Control.
 *
 * The userscript embeds the extension's REAL page-audio-hook.js engine and the
 * extension's popup.css (via the website's .vc-popup-scoped port) into
 * public/tampermonkey/volume-control.user.js.
 *
 * Sources (in resolve order):
 *   engine   repo root page-audio-hook.js   — ../page-audio-hook.js relative
 *                                             to the website/ folder, or
 *                                             $VC_ENGINE_PATH
 *   version  repo root manifest.json        — ../manifest.json
 *   css      website src/components/demo/popup.css
 *   template website tampermonkey/userscript-template.js
 *
 * Run from the website/ folder:  node scripts/build-userscript.mjs
 */

import { readFileSync, writeFileSync, mkdirSync, existsSync } from "node:fs";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const websiteRoot = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const repoRoot = resolve(websiteRoot, "..");

const enginePath = process.env.VC_ENGINE_PATH || join(repoRoot, "page-audio-hook.js");
const manifestPath = join(repoRoot, "manifest.json");
const cssPath = join(websiteRoot, "src/components/demo/popup.css");
const templatePath = join(websiteRoot, "tampermonkey/userscript-template.js");
const outPath = join(websiteRoot, "public/tampermonkey/volume-control.user.js");

if (!existsSync(templatePath)) {
    console.error(`[userscript] template missing: ${templatePath}`);
    process.exit(1);
}
if (!existsSync(cssPath)) {
    console.error(`[userscript] popup.css missing: ${cssPath}`);
    process.exit(1);
}

let engineSource = null;
for (const candidate of [enginePath, join(websiteRoot, "page-audio-hook.js")]) {
    if (existsSync(candidate)) { engineSource = readFileSync(candidate, "utf8"); break; }
}

let version = "7.1.0";
if (existsSync(manifestPath)) {
    try { version = String(JSON.parse(readFileSync(manifestPath, "utf8")).version || "7.1.0"); } catch { /* keep default */ }
}

if (engineSource === null) {
    // Website-only checkout (no extension sources around): keep the previously
    // generated artifact if present so the static site still ships the script.
    if (existsSync(outPath)) {
        console.log("[userscript] engine source not found — keeping existing generated artifact");
        process.exit(0);
    }
    console.error(`[userscript] engine source not found: ${enginePath}`);
    process.exit(1);
}

if (!engineSource.includes("__volumeControlPageAudioHook") || !engineSource.includes("BRIDGE_VERSION")) {
    console.error("[userscript] engine source failed sanity check (hook key / bridge missing)");
    process.exit(1);
}

const template = readFileSync(templatePath, "utf8");
const css = readFileSync(cssPath, "utf8");

const out = template
    .replace("__VERSION__", version)
    .replace('"__ENGINE_SOURCE__"', JSON.stringify(engineSource))
    .replace('"__POPUP_CSS__"', JSON.stringify(css));

if (out.includes("__ENGINE_SOURCE__") || out.includes("__POPUP_CSS__") || out.includes("__VERSION__")) {
    console.error("[userscript] placeholder substitution incomplete");
    process.exit(1);
}

mkdirSync(dirname(outPath), { recursive: true });
writeFileSync(outPath, out, "utf8");
console.log(`[userscript] wrote ${outPath} (${(out.length / 1024).toFixed(1)} KB, engine v${version} embedded)`);
