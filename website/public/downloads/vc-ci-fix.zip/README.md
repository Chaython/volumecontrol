# CI fix — Chaython/volumecontrol

Fixes the "Run regression tests" failure on master (all 182 tests pass again).

## What was broken (2 bugs)

1. scripts/test-build.mjs — stale assertion. Commit 5b942ce reworded the
   options.html label to "opt-in; isolated fallback route" but the test still
   expected /isolated fallback only/. Deterministic failure on every push
   since that commit. → regex updated to match the current label.

2. scripts/build.ps1 — Node resolution. On newer runner images several
   Node.js entries exist in PATH; Get-Command then returns an array whose
   .Source joins all paths with spaces, and the build fails with
   "The term 'path1 path2' is not recognized". → Select-Object -First 1.

## Apply

Copy both files over the ones in your repo's scripts/ folder:

    Copy-Item -Force build.ps1  ..\..\path\to\volumecontrol\scripts\build.ps1
    Copy-Item -Force test-build.mjs ..\..\path\to\volumecontrol\scripts\test-build.mjs

Then commit + push:

    git add scripts/build.ps1 scripts/test-build.mjs
    git commit -m "Fix CI: update reworded options label assertion, robust node resolution"
    git push origin master

Verified: node --test scripts/test-build.mjs → 182 pass / 0 fail
(with PowerShell 7.4 + Node 24; the regex fix is the one GitHub's
windows-latest runner needs — it fails before build.ps1 is ever invoked).
